touch out.txt
javac Main.java
java Main > out.txt