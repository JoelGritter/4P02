import sys

for line in sys.stdin.readlines():
    print(line.strip())