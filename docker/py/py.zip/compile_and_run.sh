touch out.txt
python main.py > out.txt