touch out.txt 
clang++ -o main main.cpp
./main > out.txt