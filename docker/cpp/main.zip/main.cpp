#include <string>
#include <iostream>

int main() {
    int in;
    std::cin >> in;
    std::cout << (char)(in+97) << "\n";
}